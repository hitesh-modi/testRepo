This update is for IBM Datacap 9.0.1. FP2

This updates the EqualizeUnbalancedImage action.  Previously it would only balance an image whenone dimension was exactly half of the other dimension.  Now it will balance all images when the input parameter is "0".

To Install:
1. Close any open Datacap applications and stop any Datacap processes.
2. Backup the existing file to a different directory before copying the updated file.
3. Copy the new file in this zip file over the existing file.