This update is for IBM Datacap 9.0.1. FP2

This update allows zoning of a table area to help identification of a table by the recognition engine.  Refer to the Recognize action help for use of the y_TableZone DCO variable to idnetify the field that has the zone coordinates for the table.

To Install:
1. Close any open Datacap applications and stop any datacap processes.
2. Backup the 2 existing files to a different directory before copying the updated files over the old files.
3. Copy the 2 new files in this zip file over the existing files.